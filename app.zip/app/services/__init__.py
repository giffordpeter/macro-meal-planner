from app.services.meal_generator import MealGeneratorService

meal_generator = MealGeneratorService()

__all__ = ['meal_generator']
