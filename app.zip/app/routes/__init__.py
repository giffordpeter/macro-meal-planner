from app.routes import meal_plans, preferences

__all__ = ['meal_plans', 'preferences']
